#include <iostream>
#include "URL.h"

using namespace std;

void processURL(string protocol, string resource)
{
	try
	{
		URL* url = new URL(protocol, resource);
		url->displayURL();
	}
	catch (const std::runtime_error& ex)
	{
		cerr << "Error: " << ex.what() << endl;
	}
}

int main()
{
	processURL("hppt:/", "google.com/");
	processURL("http:/", "google.com/");
	processURL("http:/", "www.google.com/");
	processURL("http://", "www.google.com/");
	processURL("https://", "www.google.com/");
}